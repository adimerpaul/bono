<?php

namespace App\Http\Controllers;

use App\Models\Hijo;
use App\Models\Madre;
use Illuminate\Http\Request;

class HijoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function verificar($id,$fecha){
        return Madre::where('ci',$id)
        //->whereDate('fechanac',$fecha)
        ->get();
    }

    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Hijo  $hijo
     * @return \Illuminate\Http\Response
     */
    public function show(Hijo $hijo)
    {
        //
    }

    
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Hijo  $hijo
     * @return \Illuminate\Http\Response
     */
    public function edit(Hijo $hijo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Hijo  $hijo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Hijo $hijo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Hijo  $hijo
     * @return \Illuminate\Http\Response
     */
    public function destroy(Hijo $hijo)
    {
        //
    }
}
